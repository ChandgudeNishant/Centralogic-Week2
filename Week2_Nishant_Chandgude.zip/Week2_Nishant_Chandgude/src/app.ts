import express = require("express");
import * as bodyParser from "body-parser";
import { Request, Response } from "express";
import { Pool } from "pg";

const app = express();
const port = 3000;

app.use(bodyParser.json());

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "TestOrder",
  password: "Darshan@123",
  port: 5432,
});

const checkTableExistence = async (): Promise<boolean> => {
  const query = `SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'orders'
  )`;

  const result = await pool.query(query);
  return result.rows[0].exists;
};

app.post("/filter-orders", async (req: Request, res: Response) => {
  try {
    const { items } = req.body;

    if (!items || !Array.isArray(items)) {
      return res.status(400).json({ error: "Invalid request body" });
    }

    const filteredOrders = items.filter((order: any) => {
      return order.OrderBlocks.some((block: any) => {
        if (Array.isArray(block.lineNo)) {
          return block.lineNo.some((line: number) => line % 3 !== 0);
        } else {
          return block.lineNo % 3 !== 0;
        }
      });
    });

    await Promise.all(
      filteredOrders.map(async (order: any) => {
        const orderID = order.orderID;
        const query = "INSERT INTO orders (orderID) VALUES ($1)";
        await pool.query(query, [orderID]);
      })
    );

    res
      .status(200)
      .json({ message: "Orders filtered and stored successfully." });
  } catch (error: any) {
    console.error("Error processing request:", error);
    res
      .status(500)
      .json({ error: "Internal server error", details: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
