interface Student {
  name: string;
  age: number;
  grade: number;
}

const students: Student[] = [
  { name: "Alice", age: 20, grade: 75 },
  { name: "Bob", age: 22, grade: 85 },
  { name: "Charlie", age: 21, grade: 60 },
  { name: "David", age: 19, grade: 45 },
  { name: "Eve", age: 20, grade: 90 },
];

const filterPassedStudents = (students: Student[]): Student[] =>
  students.filter((student) => student.grade >= 50);
console.log("Passed Students:", filterPassedStudents(students));

const getStudentNames = (students: Student[]): string[] =>
  students.map((student) => student.name);
console.log("Student Names:", getStudentNames(students));

const sortStudentsByGrade = (students: Student[]): Student[] =>
  students.sort((a, b) => a.grade - b.grade);
console.log("Students Sorted by Grade:", sortStudentsByGrade(students));

const getAverageAge = (students: Student[]): number => {
  const totalAge = students.reduce((acc, student) => acc + student.age, 0);
  return totalAge / students.length;
};
console.log("Average Age:", getAverageAge(students));
