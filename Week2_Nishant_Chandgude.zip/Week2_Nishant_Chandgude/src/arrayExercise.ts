const array: number[] = [1, 2, 3, 4, 5];

const mappedArray: number[] = array.map((num: number) => num * 2);
console.log("Mapped Array:", mappedArray);

const filteredArray: number[] = array.filter((num: number) => num % 2 === 0);
console.log("Filtered Array:", filteredArray);

const sum: number = array.reduce((acc: number, curr: number) => acc + curr, 0);
console.log("Sum:", sum);

array.forEach((num: number) => console.log(num));